type Props = {}
export default function AccountTypeSelect({}: Props) {
  return (
    <div>acount-type-select</div>
  )
}
export type CommonApiError = {
  status: number;
  error: string;
  message: string;
};

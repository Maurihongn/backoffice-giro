export type GetSapCeCoResponse = SapCeCo[]

export interface SapCeCo {
  nroPlanta: string
  planta: string
}

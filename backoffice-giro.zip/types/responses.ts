export type CommonApiResponse ={
    status: number;
    error: string;
    message: string;
}
export type GetRolesResponse = Role[]

export interface Role {
  roleId?: string
  roleName: string
}
